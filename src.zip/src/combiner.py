import torch
import torch.nn as nn
import torch.nn.functional as F

class Combiner(nn.Module):
    def __init__(self, convex_tensor: bool, input_dim: int, comb_proj: bool, comb_fusion: str,
                 use_cross_attn: bool = False, num_heads: int = 4):
        super().__init__()
        self.map_dim = input_dim
        self.comb_proj = comb_proj
        self.comb_fusion = comb_fusion
        self.convex_tensor = convex_tensor
        self.use_cross_attn = use_cross_attn
        self.num_heads = num_heads

        # Enhanced projection architecture
        if self.comb_proj:
            self.img_proj = self._build_projection()
            self.txt_proj = self._build_projection()
            comb_in_dim = 2 * self.map_dim  # Expanded dimension
        else:
            comb_in_dim = self.map_dim

        # Multi-scale cross attention
        if self.use_cross_attn:
            self.cross_attn = nn.MultiheadAttention(
                embed_dim=comb_in_dim,
                num_heads=num_heads,
                dropout=0.1,
                batch_first=True
            )
            self.attn_norm = nn.LayerNorm(comb_in_dim)
            self.ffn = nn.Sequential(
                nn.Linear(comb_in_dim, 4 * comb_in_dim),
                nn.GELU(),
                nn.Linear(4 * comb_in_dim, comb_in_dim),
                nn.Dropout(0.1)
            )
            self.ffn_norm = nn.LayerNorm(comb_in_dim)

        # Dynamic fusion components
        self.fusion_type = comb_fusion
        if comb_fusion == 'concat':
            self.fusion = nn.Sequential(
                nn.Linear(2 * comb_in_dim, comb_in_dim),
                nn.GELU(),
                nn.LayerNorm(comb_in_dim)
            )
        elif comb_fusion == 'align':
            self.fusion = nn.Sequential(
                nn.Linear(comb_in_dim, comb_in_dim),
                nn.Sigmoid()
            )

        # Output branches with residual connections
        self.side_branch = self._build_output_branch(comb_in_dim, 
                                                    self.map_dim if convex_tensor else 1,
                                                    final_activation=nn.Sigmoid())
        
        self.central_branch = self._build_output_branch(comb_in_dim, 
                                                      self.map_dim)

    def _build_projection(self) -> nn.Module:
        return nn.Sequential(
            nn.Linear(self.map_dim, 2 * self.map_dim),
            nn.GELU(),
            nn.LayerNorm(2 * self.map_dim),
            nn.Dropout(0.2),
            nn.Linear(2 * self.map_dim, 2 * self.map_dim),
            nn.LayerNorm(2 * self.map_dim)
        )

    def _build_output_branch(self, in_dim: int, out_dim: int, 
                           final_activation: nn.Module = None) -> nn.Module:
        layers = [
            nn.Linear(in_dim, 2 * in_dim),
            nn.GELU(),
            nn.LayerNorm(2 * in_dim),
            nn.Dropout(0.2),
            nn.Linear(2 * in_dim, out_dim)
        ]
        if final_activation:
            layers.append(final_activation)
        return nn.Sequential(*layers)

    def forward(self, img_projection: torch.Tensor, 
               post_features: torch.Tensor) -> torch.Tensor:
        # Project features
        if self.comb_proj:
            proj_img = self.img_proj(img_projection)
            proj_txt = self.txt_proj(post_features)
        else:
            proj_img = img_projection
            proj_txt = post_features

        # Cross-modal attention
        if self.use_cross_attn:
            # Prepare sequences for attention
            img_seq = proj_img.unsqueeze(1)  # [B, 1, D]
            txt_seq = proj_txt.unsqueeze(1)
            
            # Bidirectional attention
            attn_out, _ = self.cross_attn(
                query=torch.cat([img_seq, txt_seq], dim=1),
                key=torch.cat([txt_seq, img_seq], dim=1),
                value=torch.cat([txt_seq, img_seq], dim=1)
            )
            
            # Split and process
            attn_img, attn_txt = attn_out.chunk(2, dim=1)
            proj_img = self.attn_norm(proj_img + attn_img.squeeze(1))
            proj_txt = self.attn_norm(proj_txt + attn_txt.squeeze(1))
            
            # Feed forward network
            proj_img = self.ffn_norm(proj_img + self.ffn(proj_img))
            proj_txt = self.ffn_norm(proj_txt + self.ffn(proj_txt))

        # Feature fusion
        if self.fusion_type == 'concat':
            combined = torch.cat([proj_img, proj_txt], dim=-1)
            fused = self.fusion(combined)
        else:  # 'align'
            gate = self.fusion(proj_img + proj_txt)
            fused = gate * proj_img + (1 - gate) * proj_txt

        # Branch processing
        side_out = self.side_branch(fused)
        central_out = self.central_branch(fused)

        # Final combination
        if self.convex_tensor:
            output = central_out + side_out * post_features + (1 - side_out) * img_projection
        else:
            output = central_out + side_out * (img_projection + post_features)

        return output