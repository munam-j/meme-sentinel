import os
import pandas as pd
import torch
import clip

from PIL import Image
from torch.utils.data import Dataset

os.environ['CUDA_LAUNCH_BLOCKING'] = "1"


class MemesDataset(Dataset):
    def __init__(self, root_folder, dataset, split='train', image_size=224, fast=True, contrastive=False):
        """
        Dataset class for multimodal meme classification.

        Args:
            root_folder (str): Path to the dataset root directory.
            dataset (str): Dataset name (e.g., 'hmc', 'harmeme').
            split (str): Dataset split ('train', 'test', 'val').
            image_size (int): Image resizing dimension.
            fast (bool): Whether to use precomputed CLIP embeddings.
            contrastive (bool): Enable contrastive learning with positive/negative pairs.
        """
        super(MemesDataset, self).__init__()
        self.root_folder = root_folder
        self.dataset = dataset
        self.split = split
        self.image_size = image_size
        self.fast = fast
        self.contrastive = contrastive

        self.info_file = os.path.join(root_folder, dataset, f'labels/{dataset}_info.csv')
        self.df = pd.read_csv(self.info_file)
        self.df = self.df[self.df['split'] == self.split].reset_index(drop=True)
        float_cols = self.df.select_dtypes(float).columns
        self.df[float_cols] = self.df[float_cols].fillna(-1).astype('Int64')

        if self.fast:
           self.embds = torch.load(f'{self.root_folder}/{self.dataset}/clip_embds/{split}_no-proj_output.pt',
                                 map_location='cuda' if torch.cuda.is_available() else 'cpu')
           self.embdsDF = pd.DataFrame(self.embds)
           assert len(self.embds) == len(self.df)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        if row['text'] == 'nothing':
            txt = 'null'
        else:
            txt = row['text']

        if self.fast:
            embd_idx = self.embdsDF.loc[self.embdsDF['idx_meme'] == row['id']].index[0]
            embd_row = self.embds[embd_idx]

            image = embd_row['image']
            text = embd_row['text']
        else:
            if self.dataset == 'hmc':
                image_fn = row['img'].split('/')[1]
            else:
                image_fn = row['image']

            image = Image.open(f"{self.root_folder}/{self.dataset}/img/{image_fn}").convert('RGB')
            image = image.resize((self.image_size, self.image_size))
            text = txt

        item = {
            'image': image,
            'text': text,
            'prompt': f'a photo of $ , {txt}',  # Added prompt key
            'label': row['label'],
            'idx_meme': row['id'],
            'origin_text': txt
        }

        # Contrastive Learning: Create positive & negative pairs
        if self.contrastive and self.split == 'train':
            # Select a random meme from the dataset as a negative sample
            neg_idx = torch.randint(0, len(self.df), (1,)).item()
            neg_row = self.df.iloc[neg_idx]

            neg_image_fn = neg_row['img'].split('/')[1] if self.dataset == 'hmc' else neg_row['image']
            neg_image = Image.open(f"{self.root_folder}/{self.dataset}/img/{neg_image_fn}").convert('RGB')
            neg_image = neg_image.resize((self.image_size, self.image_size))

            item['neg_image'] = neg_image
            item['neg_text'] = neg_row['text']

        return item


class MemesCollator(object):
    def __init__(self, args):
        self.args = args
        if not args.fast_process:
            _, self.clip_preprocess = clip.load("ViT-L/14", device="cuda", jit=False)

    def __call__(self, batch):
        """
        Custom collator function for batch processing.
        """
        labels = torch.LongTensor([item['label'] for item in batch])
        idx_memes = torch.LongTensor([item['idx_meme'] for item in batch])

        # Get prompts from batch items
        prompts = [item['prompt'] for item in batch]
        prompt_tokens = clip.tokenize(prompts, context_length=77, truncate=True)
        
        text_input = []
        for el in batch:
            text_input.append(
                clip.tokenize(f'{"a photo of $"} , {el["origin_text"]}', context_length=77, truncate=True)
            )

        enh_texts = torch.cat([item for item in text_input], dim=0)
        simple_prompt = clip.tokenize('a photo of $', context_length=77).repeat(labels.shape[0], 1)

        batch_new = {
            'labels': labels,
            'idx_memes': idx_memes,
            'enhanced_texts': enh_texts,
            'simple_prompt': simple_prompt,
            'prompt': prompt_tokens,  # Added prompt to batch
            'prompt_texts': prompts   # Added raw prompt texts
        }

        if self.args.fast_process:
            images_emb = torch.cat([item['image'] for item in batch], dim=0)
            texts_emb = torch.cat([item['text'] for item in batch], dim=0)

            batch_new['images'] = images_emb
            batch_new['texts'] = texts_emb
        else:
            img = []
            texts = []
            neg_img = []
            neg_texts = []

            for item in batch:
                pixel_values = self.clip_preprocess(item['image']).unsqueeze(0)
                img.append(pixel_values)

                text = clip.tokenize(item['text'], context_length=77, truncate=True)
                texts.append(text)

                # For contrastive learning: prepare negative pairs
                if 'neg_image' in item:
                    neg_pixel_values = self.clip_preprocess(item['neg_image']).unsqueeze(0)
                    neg_img.append(neg_pixel_values)

                    neg_text = clip.tokenize(item['neg_text'], context_length=77, truncate=True)
                    neg_texts.append(neg_text)

            batch_new['pixel_values'] = torch.cat(img, dim=0)
            batch_new['texts'] = torch.cat(texts, dim=0)

            if neg_img and neg_texts:
                batch_new['neg_pixel_values'] = torch.cat(neg_img, dim=0)
                batch_new['neg_texts'] = torch.cat(neg_texts, dim=0)

        return batch_new


def load_dataset(args, split):
    dataset = MemesDataset(
        root_folder=f'./resources/datasets',
        dataset=args.dataset,
        split=split,
        image_size=args.image_size,
        fast=args.fast_process,
        contrastive=args.contrastive
    )
    return dataset