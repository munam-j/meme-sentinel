import argparse
import random
import torch
from pytorch_lightning import Trainer, seed_everything
from pytorch_lightning.callbacks import ModelCheckpoint, LearningRateMonitor
from pytorch_lightning.loggers import WandbLogger
from torch.utils.data import DataLoader

from datasets import MemesCollator, load_dataset
from engine import create_model, HateClassifier
from utils import str2bool, generate_name, add_new_arguments
import torch.serialization
from argparse import Namespace

torch.serialization.add_safe_globals([Namespace])


def get_arg_parser():
    parser = argparse.ArgumentParser(description='Training and evaluation script for hateful memes classification')

    # Dataset and basic training parameters
    parser.add_argument('--dataset', default='hmc', choices=['hmc', 'harmeme'])
    parser.add_argument('--image_size', type=int, default=224)
    parser.add_argument('--batch_size', type=int, default=16, help='Batch size')
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--gradient_clip_val', type=float, default=0.1)
    
    # Architecture parameters
    parser.add_argument('--num_mapping_layers', default=1, type=int)
    parser.add_argument('--map_dim', default=768, type=int)
    parser.add_argument('--num_pre_output_layers', default=1, type=int)
    parser.add_argument('--drop_probs', type=float, nargs=3, default=[0.1, 0.4, 0.2],
                      help="Set drop probabilities for map, fusion, pre_output")
    
    # Model type and fusion
    parser.add_argument('--name', type=str, default='adaptation',
                      choices=['adaptation', 'hate-clipper', 'image-only', 'text-only', 
                              'sum', 'combiner', 'text-inv', 'text-inv-fusion', 'text-inv-comb'])
    parser.add_argument('--fusion', default='align', choices=['align', 'concat'])
    
    # Projection and freezing
    parser.add_argument('--proj_map', default=False, type=str2bool)
    parser.add_argument('--pretrained_proj_weights', default=False, type=str2bool)
    parser.add_argument('--freeze_proj_layers', default=False, type=str2bool)
    
    # Combiner specific
    parser.add_argument('--comb_proj', default=False, type=str2bool)
    parser.add_argument('--comb_fusion', default='align', choices=['concat', 'align'])
    parser.add_argument('--convex_tensor', default=False, type=str2bool)
    
    # Textual inversion
    parser.add_argument('--text_inv_proj', default=False, type=str2bool)
    parser.add_argument('--phi_inv_proj', default=False, type=str2bool)
    parser.add_argument('--post_inv_proj', default=False, type=str2bool)
    parser.add_argument('--enh_text', default=False, type=str2bool)
    parser.add_argument('--phi_freeze', default=False, type=str2bool)
    
    # Training control
    parser.add_argument('--gpus', default='0', help='GPU ids concatenated with space')
    parser.add_argument('--limit_train_batches', default=1.0)
    parser.add_argument('--limit_val_batches', default=1.0)
    parser.add_argument('--max_steps', type=int, default=-1)
    parser.add_argument('--max_epochs', type=int, default=-1)
    parser.add_argument('--log_every_n_steps', type=int, default=25)
    parser.add_argument('--val_check_interval', default=1.0)
    
    # Misc
    parser.add_argument('--pretrained_model', type=str, default='')
    parser.add_argument('--reproduce', default=False, type=str2bool)
    parser.add_argument('--print_model', default=False, type=str2bool)
    parser.add_argument('--fast_process', default=False, type=str2bool)
    
    # Add new arguments for hybrid combiner and instruction tuning
    parser = add_new_arguments(parser)
    
    return parser


def main(args):
    # Set random seeds for reproducibility
    seed_everything(42, workers=True)
    
    # Generate run name with all configuration details
    run_name = f'{generate_name(args)}-{random.randint(0, 1000000000)}'
    print(f"Starting run: {run_name}")

    # Load dataset
    if args.dataset == 'hmc':
        splits = {
            'train': load_dataset(args=args, split='train'),
            'val': load_dataset(args=args, split='dev_seen'),
            'test': load_dataset(args=args, split='test_seen'),
            'val_unseen': load_dataset(args=args, split='dev_unseen'),
            'test_unseen': load_dataset(args=args, split='test_unseen')
        }
    elif args.dataset == 'harmeme':
        splits = {
            'train': load_dataset(args=args, split='train'),
            'val': load_dataset(args=args, split='val'),
            'test': load_dataset(args=args, split='test')
        }
    else:
        raise ValueError(f"Unknown dataset: {args.dataset}")

    # Print dataset statistics
    for split_name, dataset in splits.items():
        print(f"Number of {split_name} examples:", len(dataset))

    # Create data loaders
    num_cpus = 0 if args.fast_process else min(args.batch_size, 24)
    collator = MemesCollator(args)
    
    dataloaders = {
        'train': DataLoader(splits['train'], batch_size=args.batch_size, 
                          shuffle=True, collate_fn=collator, num_workers=num_cpus),
        'val': DataLoader(splits['val'], batch_size=args.batch_size,
                         collate_fn=collator, num_workers=num_cpus),
        'test': DataLoader(splits['test'], batch_size=args.batch_size,
                          collate_fn=collator, num_workers=num_cpus)
    }
    
    if args.dataset == 'hmc':
        dataloaders.update({
            'val_unseen': DataLoader(splits['val_unseen'], batch_size=args.batch_size,
                                   collate_fn=collator, num_workers=num_cpus),
            'test_unseen': DataLoader(splits['test_unseen'], batch_size=args.batch_size,
                                    collate_fn=collator, num_workers=num_cpus)
        })

    # Initialize model
    model = create_model(args)

    if args.print_model:
        print(model)
        return

    # Setup logging and callbacks
    wandb_logger = WandbLogger(project="hateful-memes", name=run_name, config=args)
    
    # Log number of trainable parameters
    num_trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    wandb_logger.experiment.config.update({'total_trainable_params': num_trainable_params})

    # Setup callbacks
    callbacks = [
        ModelCheckpoint(
            dirpath='checkpoints',
            filename=run_name+'-{epoch:02d}',
            monitor="val/auroc",
            mode='max',
            save_top_k=1,
            save_weights_only=True
        ),
        LearningRateMonitor(logging_interval='step')
    ]

    # Initialize trainer
    trainer = Trainer(
        accelerator='gpu',
        devices=args.gpus,
        max_epochs=args.max_epochs,
        max_steps=args.max_steps,
        gradient_clip_val=args.gradient_clip_val,
        logger=wandb_logger,
        log_every_n_steps=args.log_every_n_steps,
        val_check_interval=args.val_check_interval,
        callbacks=callbacks,
        limit_train_batches=args.limit_train_batches,
        limit_val_batches=args.limit_val_batches,
        deterministic=False
    )

    # Run training or testing
    if not args.reproduce:
        trainer.fit(model, train_dataloaders=dataloaders['train'], val_dataloaders=dataloaders['val'])
        
        test_dataloaders = [dataloaders['val'], dataloaders['test']]
        if args.dataset == 'hmc':
            test_dataloaders.extend([dataloaders['val_unseen'], dataloaders['test_unseen']])
            
        trainer.test(ckpt_path='best', dataloaders=test_dataloaders)
    else:
        test_dataloaders = [dataloaders['val'], dataloaders['test']]
        if args.dataset == 'hmc':
            test_dataloaders.extend([dataloaders['val_unseen'], dataloaders['test_unseen']])
            
        trainer.test(model, dataloaders=test_dataloaders)


if __name__ == '__main__':
    parser = get_arg_parser()
    args = parser.parse_args()
    
    # Process GPU argument
    args.gpus = [int(id_) for id_ in args.gpus.split()]
    for gpu_id in args.gpus:
        print(f'Using GPU {gpu_id}: {torch.cuda.get_device_properties(gpu_id)}')
    
    main(args)