import torch
import torch.nn as nn
from clip.model import CLIP

PHI_INPUT_DIM = 768

class TextualInversion(nn.Module):
    def __init__(self, clip_model: CLIP, clip_img_enc_output_dim: int, phi_proj: bool, text_proj: bool, post_proj: bool,
                 drop_probs, phi_freeze: bool, enh_text: bool, post_dim=None, num_pre_proj_layers=1):
        super(TextualInversion, self).__init__()
        
        self.clip_model = clip_model
        self.phi_proj = phi_proj
        self.text_proj = text_proj
        self.post_proj = post_proj
        self.enh_text = enh_text
        self.special_token_id = 259  # CLIP token ID for '$'

        assert self.clip_model.token_embedding.embedding_dim == PHI_INPUT_DIM, \
            'CLIP model selected is not compatible with the pre-trained phi network'

        # Initialize phi network
        self.phi = nn.Sequential(
            nn.Linear(PHI_INPUT_DIM, 3072),
            nn.GELU(),
            nn.Dropout(p=0.5),
            nn.Linear(3072, 3072),
            nn.GELU(),
            nn.Dropout(p=0.5),
            nn.Linear(3072, PHI_INPUT_DIM)
        )

        # Load pre-trained weights
        phi_dict = torch.load("./resources/pretrained_weights/phi/phi_imagenet_45.pt")["MLPCustom"]
        with torch.no_grad():
            for i, layer in enumerate([0, 3, 6]):
                self.phi[layer].weight.copy_(phi_dict[f'layers.{layer}.weight'])
                self.phi[layer].bias.copy_(phi_dict[f'layers.{layer}.bias'])

        if phi_freeze:
            for p in self.phi.parameters():
                p.requires_grad_(False)

        # Projection layers
        if phi_proj:
            self.phi_map = nn.Sequential(
                nn.Linear(PHI_INPUT_DIM, PHI_INPUT_DIM),
                nn.Dropout(p=drop_probs[0])
            )

        # Image feature projection
        layers = [nn.Linear(clip_img_enc_output_dim, PHI_INPUT_DIM),
                 nn.Dropout(p=drop_probs[0])]
        for _ in range(1, num_pre_proj_layers):
            layers.extend([
                nn.ReLU(),
                nn.Linear(PHI_INPUT_DIM, PHI_INPUT_DIM),
                nn.Dropout(p=drop_probs[0])
            ])
        self.pre_inversion_map = nn.Sequential(*layers)

        # Post inversion projection
        if post_proj:
            self.post_inversion_map = nn.Sequential(
                nn.Linear(self.clip_model.token_embedding.embedding_dim, post_dim),
                nn.Dropout(p=drop_probs[0])
            )
            self.output_dim = post_dim
        else:
            self.output_dim = self.clip_model.token_embedding.embedding_dim

    def encode_with_vstar(self, clip_model: CLIP, text: torch.Tensor, v_star: torch.Tensor, 
                         num_vstar=1, pooling=True, proj=True):
        """Enhanced version with robust special token handling"""
        x = clip_model.token_embedding(text).type(clip_model.dtype)
        
        # Find all special token positions
        special_positions = (text == self.special_token_id).nonzero(as_tuple=False)
        
        if len(special_positions) == 0:
            # Fallback to normal encoding if no special tokens found
            x = x + clip_model.positional_embedding.type(clip_model.dtype)
            x = x.permute(1, 0, 2)
            x = clip_model.transformer(x)
            x = x.permute(1, 0, 2)
            x = clip_model.ln_final(x).type(clip_model.dtype)
            return x[torch.arange(x.shape[0]), text.argmax(dim=-1)] @ (clip_model.text_projection if proj else 1)
        
        # Process each sample in batch
        batch_size = text.shape[0]
        for i in range(batch_size):
            # Get positions for current sample
            sample_pos = special_positions[special_positions[:, 0] == i, 1]
            
            if len(sample_pos) > 0:
                # Replace first occurrence per sample
                x[i, sample_pos[0]] = v_star[i] if v_star.dim() == 2 else v_star[i].unsqueeze(0)
        
        # Standard CLIP text encoding
        x = x + clip_model.positional_embedding.type(clip_model.dtype)
        x = x.permute(1, 0, 2)
        x = clip_model.transformer(x)
        x = x.permute(1, 0, 2)
        x = clip_model.ln_final(x).type(clip_model.dtype)
        
        if pooling:
            pooled = x[torch.arange(x.shape[0]), text.argmax(dim=-1)]
            return pooled @ clip_model.text_projection if proj else pooled
        return x

    def forward(self, prompt, image_features):
        # Process image features
        img_features = self.pre_inversion_map(image_features)
        v_star = self.phi(img_features)
        
        if self.phi_proj:
            v_star = self.phi_map(v_star)
        
        # Process text with visual token
        features = self.encode_with_vstar(
            self.clip_model, 
            prompt, 
            v_star, 
            proj=self.text_proj
        ).float()
        
        if self.post_proj:
            features = self.post_inversion_map(features)
            
        return features