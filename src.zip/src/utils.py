import argparse

def str2bool(v):
    """
    Robust boolean argument parser.
    Supports various true/false string representations.
    """
    if isinstance(v, bool):
        return v
    v = str(v).strip().lower()
    if v in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v in ('no', 'false', 'f', 'n', '0'):
        return False
    raise argparse.ArgumentTypeError('Boolean value expected.')

def generate_name(args):
    """Generate experiment name from configuration"""
    terms = [args.name, args.dataset]

    # Model architecture components
    if args.name in ['combiner', 'text-inv-comb']:
        if getattr(args, 'pretrained_proj_weights', False):
            terms.append('pt-proj' + ('-frozen' if getattr(args, 'freeze_proj_layers', False) else '-ft'))
        terms.append(f'{args.num_mapping_layers}-{args.map_dim}proj')

    # Textual inversion specific
    if args.name in ['text-inv', 'text-inv-fusion', 'text-inv-comb']:
        if getattr(args, 'text_inv_proj', False):
            terms.append('txt-proj')
        if getattr(args, 'phi_inv_proj', False):
            terms.append('phi-proj')
        if getattr(args, 'post_inv_proj', False):
            terms.append(f'post-{args.map_dim}proj')

    # Cross-attention and combiner
    if getattr(args, 'use_cross_attn', False):
        terms.append(f'xattn-{args.num_heads}h')
        if getattr(args, 'attn_residual', True):
            terms.append('res')
        if getattr(args, 'attn_dropout', 0.1) > 0:
            terms.append(f'dp{args.attn_dropout}')

    # New training features
    if getattr(args, 'contrastive', False):
        terms.append(f'con-{args.contrastive_temp}temp')
    if getattr(args, 'label_smoothing', 0) > 0:
        terms.append(f'sm{args.label_smoothing}')
    if getattr(args, 'instruction_tuning', False):
        terms.append(f'lora-{args.lora_rank}')

    # Training configuration
    terms.extend([
        f'{args.fusion[:3]}',
        f'bs{args.batch_size}',
        f'lr{args.lr:.0e}',
        f'wd{args.weight_decay:.0e}'
    ])

    # Filter and join valid terms
    return '_'.join(filter(None, terms))

def add_new_arguments(parser):
    """Add all new experimental arguments to the parser"""
    
    # Cross-attention parameters
    parser.add_argument('--use_cross_attn', type=str2bool, default=False,
                      help='Enable cross-attention in Combiner')
    parser.add_argument('--num_heads', type=int, default=4,
                      help='Number of attention heads')
    parser.add_argument('--attn_residual', type=str2bool, default=True,
                      help='Use residual connections in attention')
    parser.add_argument('--attn_dropout', type=float, default=0.1,
                      help='Attention dropout rate')

    # Contrastive learning
    parser.add_argument('--contrastive', type=str2bool, default=False,
                      help='Enable contrastive learning')
    parser.add_argument('--contrastive_temp', type=float, default=0.07,
                      help='Temperature for contrastive loss')
    
    # Instruction tuning
    parser.add_argument('--instruction_tuning', type=str2bool, default=False,
                      help='Enable CLIP instruction tuning')
    parser.add_argument('--lora_rank', type=int, default=8,
                      help='LoRA rank for instruction tuning')
    parser.add_argument('--unfreeze_layers', type=int, default=0,
                      help='Number of CLIP layers to unfreeze')

    # Regularization
    parser.add_argument('--label_smoothing', type=float, default=0.0,
                      help='Label smoothing epsilon')
    #parser.add_argument('--weight_decay', type=float, default=1e-4,
                      #help='Weight decay for optimizer')

    # Training optimization
    parser.add_argument('--lr_scheduler', type=str2bool, default=True,
                      help='Enable learning rate scheduling')
    parser.add_argument('--lr_patience', type=int, default=3,
                      help='LR scheduler patience (epochs)')
    parser.add_argument('--lr_factor', type=float, default=0.5,
                      help='LR reduction factor')
    parser.add_argument('--comb_skip', type=bool, default=True, help='Whether to use skip connection in combiner')
    
    return parser

def validate_args(args):
    """Validate argument combinations"""
    if args.contrastive and not args.fast_process:
        args.augment = True  # Force augmentations for contrastive learning
        
    if args.instruction_tuning and args.lora_rank <= 0:
        raise ValueError("LoRA rank must be positive when instruction tuning is enabled")
    
    return args