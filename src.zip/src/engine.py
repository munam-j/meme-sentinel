import pytorch_lightning as pl
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchmetrics
import clip
from peft import LoraConfig, get_peft_model
import os
from sklearn.manifold import TSNE
import umap
import numpy as np
from sklearn.metrics import confusion_matrix, roc_curve, precision_recall_curve, roc_auc_score, average_precision_score
import seaborn as sns
import matplotlib.pyplot as plt
from combiner import Combiner
from textualInversion import TextualInversion

CLIP_IMG_ENC_OUTPUT_DIM_BEFORE_PROJ = 1024

class LinearProjection(nn.Module):
    def __init__(self, input_dim, output_dim, num_layers, drop_probs):
        super(LinearProjection, self).__init__()
        map_layers = [nn.Linear(input_dim, output_dim),
                     nn.Dropout(p=drop_probs[0])]
        for _ in range(1, num_layers):
            map_layers.extend(
                [nn.ReLU(), nn.Linear(output_dim, output_dim), nn.Dropout(p=drop_probs[0])])
        self.proj = nn.Sequential(*map_layers)

    def forward(self, x):
        return self.proj(x)

class HateClassifier(pl.LightningModule):
    def __init__(self, args):
        super().__init__()
        self.save_hyperparameters()
        self.args = args
        self.test_preds = []
        self.test_probs = []
        self.test_labels = []
        self.test_features = []
        self.args = args
        self.dataset = args.dataset
        self.num_mapping_layers = args.num_mapping_layers
        self.map_dim = args.map_dim
        self.fusion = args.fusion
        self.lr = args.lr
        self.weight_decay = args.weight_decay
        self.batch_size = args.batch_size
        self.name = args.name
        self.fast_process = args.fast_process
        self.instruction_tuning = getattr(args, 'instruction_tuning', False)
        self.enh_text = args.enh_text
        self.phi_freeze = args.phi_freeze
        self.text_inv_proj = args.text_inv_proj
        self.phi_inv_proj = args.phi_inv_proj
        self.post_inv_proj = args.post_inv_proj
        
        # Initialize metrics
        self.acc = torchmetrics.Accuracy(task='binary')
        self.auroc = torchmetrics.AUROC(task='binary')
        self.f1 = torchmetrics.F1Score(task='binary')

        # Load CLIP model
        self.clip_model, _ = clip.load("ViT-L/14", device="cuda", jit=False)
        self.clip_model.visual.proj = None  # Remove image projection
        self.clip_model.float()
        
        # Freeze CLIP by default
        for param in self.clip_model.parameters():
            param.requires_grad = False

        # Instruction templates and class embeddings
        self.class_names = ["non-hateful", "hateful"]
        self.instruction_templates = [
            "Is this meme hateful? Answer: {}",
            "Does this meme contain hate speech? Answer: {}",
            "Classify this meme: {}"
        ]
        
        # Pre-compute class text embeddings
        with torch.no_grad():
            self.register_buffer('class_embeddings', self._init_class_embeddings())

        # Projection layers
        self.image_map = LinearProjection(
            CLIP_IMG_ENC_OUTPUT_DIM_BEFORE_PROJ,
            self.map_dim,
            self.num_mapping_layers,
            args.drop_probs
        )
        self.text_map = LinearProjection(
            self.clip_model.token_embedding.embedding_dim,
            self.map_dim,
            self.num_mapping_layers,
            args.drop_probs
        )

        # Combiner network
        if self.name in ['combiner', 'text-inv-comb']:
            self.combiner = Combiner(  # Changed from self.comb to self.combiner
                convex_tensor=args.convex_tensor,
                input_dim=self.map_dim,
                comb_proj=args.comb_proj,
                comb_fusion=args.comb_fusion,
                use_cross_attn=getattr(args, 'use_cross_attn', False),
                num_heads=getattr(args, 'num_heads', 4)
            )

        # Textual inversion components
        if self.name in ['text-inv', 'text-inv-comb']:
            self.text_inv = TextualInversion(
                self.clip_model,
                CLIP_IMG_ENC_OUTPUT_DIM_BEFORE_PROJ,
                args.phi_inv_proj,
                args.text_inv_proj,
                args.post_inv_proj,
                args.drop_probs,
                args.phi_freeze,
                args.enh_text,
                self.map_dim,
                self.num_mapping_layers
            )

        # Combiner output projection to CLIP space
        self.comb_proj = nn.Sequential(
            nn.Linear(self.map_dim, self.clip_model.text_projection.shape[1]),
            nn.LayerNorm(self.clip_model.text_projection.shape[1]),
            nn.Dropout(args.drop_probs[1])
        )

        # Apply LoRA for instruction tuning
        if self.instruction_tuning:
            lora_config = LoraConfig(
                r=args.lora_rank,
                lora_alpha=32,
                target_modules=["k_proj", "v_proj", "q_proj", "out_proj"],
                lora_dropout=0.1,
                bias="none"
            )
            self.clip_model.transformer = get_peft_model(
                self.clip_model.transformer,
                lora_config
            )
            self.clip_model.transformer.print_trainable_parameters()

    def _init_class_embeddings(self):
        """Initialize class embeddings using multiple prompt templates"""
        class_embeddings = []
        for name in self.class_names:
            template_embeddings = []
            for template in self.instruction_templates:
                text = template.format(name)
                tokens = clip.tokenize([text]).to("cuda")
                emb = self.clip_model.encode_text(tokens)
                template_embeddings.append(emb)
            class_embeddings.append(torch.mean(torch.stack(template_embeddings), dim=0))
        return torch.cat(class_embeddings)

    def forward(self, batch):
        # Extract features
        if self.fast_process:
            image_features = batch['images']
            text_features = batch['texts']
        else:
            image_features = self.clip_model.encode_image(batch['pixel_values'])
            text_features = self.clip_model.encode_text(batch['texts'])

        # Project features
        proj_img = self.image_map(image_features)
        proj_txt = self.text_map(text_features)

        # Textual inversion pathway
        if self.name in ['text-inv', 'text-inv-comb']:
            pseudo_word = self.text_inv(batch['prompt'], image_features)
            if self.name == 'text-inv-comb':
                proj_txt = self.combiner(proj_txt, pseudo_word)  # Now uses self.combiner
            else:
                proj_txt = pseudo_word

        # Multimodal fusion
        if self.name in ['combiner', 'text-inv-comb']:
            comb_out = self.combiner(proj_img, proj_txt)  # Now uses self.combiner
        else:
            comb_out = torch.cat([proj_img, proj_txt], dim=1) if self.fusion == 'concat' \
                      else torch.mul(proj_img, proj_txt)

        # Project to CLIP text space and normalize
        clip_space = self.comb_proj(comb_out)
        clip_space = F.normalize(clip_space, dim=-1)
        
        # Return both logits and the pre-classification features
        return {
            'logits': clip_space @ self.class_embeddings.T,
            'features_pre_output': clip_space
        }
    def compute_CLIP_features_without_proj(self, clip_model, img_input, text_input):
        # CLIP image encoder without projection
        image_features = clip_model.visual(img_input.type(clip_model.dtype))

        # CLIP text encoder without projection
        x = clip_model.token_embedding(text_input).type(clip_model.dtype)
        x = x + clip_model.positional_embedding.type(clip_model.dtype)
        x = x.permute(1, 0, 2)
        x = clip_model.transformer(x)
        x = x.permute(1, 0, 2)
        x = clip_model.ln_final(x).type(clip_model.dtype)
        text_features = x[torch.arange(x.shape[0]), text_input.argmax(dim=-1)]

        return image_features, text_features

    def common_step(self, batch):
        # Get the model outputs
        model_output = self(batch)  # This now returns a dictionary
        
        # Extract logits from the model output
        logits = model_output['logits']
        
        # Compute loss
        loss = F.cross_entropy(logits, batch['labels'])
        
        # Compute metrics
        preds = torch.argmax(logits, dim=1)
        output = {
            'loss': loss,
            'accuracy': self.acc(preds, batch['labels']),
            'auroc': self.auroc(logits[:, 1], batch['labels']),
            'f1': self.f1(preds, batch['labels']),
            'logits': logits,
            'preds': preds,
            'features_pre_output': model_output.get('features_pre_output', None)  # Include if available
        }
        return output

    def training_step(self, batch, batch_idx):
        output = self.common_step(batch)

        total_loss = output['loss']

        self.log('train/total_loss', total_loss)
        self.log('train/loss', output['loss'])
        self.log('train/accuracy', output['accuracy'])
        self.log('train/auroc', output['auroc'])
        self.log('train/f1', output['auroc'])

        return total_loss
    def validation_step(self, batch, batch_idx):
        output = self.common_step(batch)

        total_loss = output['loss']

        self.log(f'val/total_loss', total_loss)
        self.log(f'val/loss', output['loss'])
        self.log(f'val/accuracy', output['accuracy'])
        self.log(f'val/auroc', output['auroc'])
        self.log(f'val/f1', output['auroc'])

        return total_loss

    def test_step(self, batch, batch_idx, dataloader_idx=0):
        output = self.common_step(batch)
        
        # Store outputs for combined graphs
        if not hasattr(self, 'test_preds'):
            self.test_preds = []
            self.test_probs = []
            self.test_labels = []
            self.test_features = []
        
        self.test_preds.append(output['preds'].cpu())
        self.test_probs.append(torch.sigmoid(output['logits']).cpu())
        self.test_labels.append(batch['labels'].cpu())
        self.test_features.append(output['features_pre_output'].cpu())
        
        # Still log metrics per split for tracking
        if self.dataset == 'hmc':
            prefix = ['dev_seen', 'test_seen', 'dev_unseen', 'test_unseen'][dataloader_idx]
        elif self.dataset == 'harmeme':
            prefix = ['val', 'test'][dataloader_idx]
        else:
            prefix = 'test'
        
        self.log(f'{prefix}/accuracy', output['accuracy'])
        self.log(f'{prefix}/auroc', output['auroc'])
        self.log(f'{prefix}/f1', output['f1'])
        
        return output
    
    def on_test_epoch_end(self):
        # Combine all test results from all splits and datasets
        y_true = torch.cat(self.test_labels).numpy()
        y_prob = torch.cat(self.test_probs).numpy()
        y_pred = torch.cat(self.test_preds).numpy()
        features = torch.cat(self.test_features).numpy()
        
        # Only use positive class probabilities for binary classification
        if y_prob.ndim > 1 and y_prob.shape[1] > 1:
            y_prob = y_prob[:, 1]
        
        # Create directory if it doesn't exist
        os.makedirs("results", exist_ok=True)
        
        # Generate combined plots
        self._generate_combined_plots(y_true, y_pred, y_prob, features)
        
        # Clear test outputs
        del self.test_preds
        del self.test_probs
        del self.test_labels
        del self.test_features
    
    def _generate_combined_plots(self, y_true, y_pred, y_prob, features):
        """Generate combined evaluation plots for all test data"""
        # Confusion Matrix
        plt.figure()
        cm = confusion_matrix(y_true, y_pred)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                   xticklabels=['Non-Hateful', 'Hateful'],
                   yticklabels=['Non-Hateful', 'Hateful'])
        plt.title('Confusion Matrix (Combined Test Data)')
        plt.xlabel('Predicted')
        plt.ylabel('True')
        plt.savefig('results/confusion_matrix.png')
        plt.close()
    
        # ROC Curve
        plt.figure()
        fpr, tpr, _ = roc_curve(y_true, y_prob)
        auc = roc_auc_score(y_true, y_prob)
        plt.plot(fpr, tpr, label=f'AUC = {auc:.2f}')
        plt.plot([0, 1], [0, 1], 'k--')
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC Curve (Combined Test Data)')
        plt.legend()
        plt.grid(True)
        plt.savefig('results/roc_curve.png')
        plt.close()
    
        # Precision-Recall Curve
        plt.figure()
        precision, recall, _ = precision_recall_curve(y_true, y_prob)
        ap = average_precision_score(y_true, y_prob)
        plt.plot(recall, precision, label=f'AP = {ap:.2f}')
        plt.xlabel('Recall')
        plt.ylabel('Precision')
        plt.title('Precision-Recall Curve (Combined Test Data)')
        plt.legend()
        plt.grid(True)
        plt.savefig('results/precision_recall_curve.png')
        plt.close()
    
        # UMAP Embedding
        plt.figure(figsize=(8, 6))
        reducer = umap.UMAP(n_components=2, random_state=42)
        reduced = reducer.fit_transform(features)
        for label in np.unique(y_true):
            idx = y_true == label
            plt.scatter(reduced[idx, 0], reduced[idx, 1],
                       label=f"{'Hateful' if label else 'Non-Hateful'}",
                       alpha=0.6)
        plt.title('2D Embedding via UMAP (Combined Test Data)')
        plt.legend()
        plt.savefig('results/umap_embedding.png')
        plt.close()
    def configure_optimizers(self):
        # Collect all unique parameters
        param_groups = []
        seen_params = set()
        
        # Image projection parameters
        if hasattr(self, 'image_map'):
            params = [p for p in self.image_map.parameters() if p not in seen_params]
            if params:
                param_groups.append({'params': params})
                seen_params.update(params)
        
        # Text projection parameters
        if hasattr(self, 'text_map'):
            params = [p for p in self.text_map.parameters() if p not in seen_params]
            if params:
                param_groups.append({'params': params})
                seen_params.update(params)
        
        # Combiner projection parameters
        if hasattr(self, 'comb_proj'):
            params = [p for p in self.comb_proj.parameters() if p not in seen_params]
            if params:
                param_groups.append({'params': params})
                seen_params.update(params)
        
        # Textual inversion parameters with reduced LR
        if hasattr(self, 'text_inv'):
            params = [p for p in self.text_inv.parameters() if p not in seen_params]
            if params:
                param_groups.append({
                    'params': params,
                    'lr': self.lr * 0.5  # Lower learning rate for textual inversion
                })
                seen_params.update(params)
        
        # Combiner parameters
        if hasattr(self, 'comb'):
            params = [p for p in self.comb.parameters() if p not in seen_params]
            if params:
                param_groups.append({'params': params})
                seen_params.update(params)
        
        # LoRA parameters if instruction tuning is enabled
        if self.instruction_tuning and hasattr(self.clip_model, 'transformer'):
            params = [p for p in self.clip_model.transformer.parameters() if p.requires_grad and p not in seen_params]
            if params:
                param_groups.append({'params': params})
                seen_params.update(params)
        
        # Create optimizer with the collected parameter groups
        optimizer = torch.optim.AdamW(
            param_groups,
            lr=self.lr,
            weight_decay=self.weight_decay
        )
        
        # Configure learning rate scheduler
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode='max',
            factor=0.5,
            patience=3,
            verbose=True
        )
        
        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": scheduler,
                "monitor": "val/auroc",
                "interval": "epoch"
            }
        }

def create_model(args):
    return HateClassifier(args=args)